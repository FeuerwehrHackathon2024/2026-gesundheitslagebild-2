#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HL7 ADT Nachrichten-Generator für Hackathons
============================================

Erzeugt realistische Admission/Discharge/Transfer Nachrichten (HL7 v2.5)
mit deutschen Stammdaten und §301-kompatiblen Feldinhalten.

Unterstützte Trigger Events
---------------------------
  A01  Aufnahme stationär         ADT^A01^ADT_A01
  A02  Verlegung                  ADT^A02^ADT_A02
  A03  Entlassung                 ADT^A03^ADT_A03
  A04  Ambulante Registrierung    ADT^A04^ADT_A01
  A05  Vor-Aufnahme                ADT^A05^ADT_A05
  A08  Stammdaten-Update          ADT^A08^ADT_A01
  A11  Aufnahme stornieren         ADT^A11^ADT_A09
  A13  Entlassung stornieren       ADT^A13^ADT_A01
  A40  Patienten-Merge             ADT^A40^ADT_A39

Aufruf
------
    python hl7_adt_generator.py                          # 5 × A01
    python hl7_adt_generator.py --event A03 -n 10        # 10 Entlassungen
    python hl7_adt_generator.py --mix -n 20              # zufälliger Ereignismix
    python hl7_adt_generator.py --chain -n 3             # 3 komplette Fallverläufe
    python hl7_adt_generator.py --scenario kardio --seed 42
    python hl7_adt_generator.py --mllp -o adt.mllp

Alle Patientendaten sind rein fiktiv.
"""

import argparse
import random
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

# ────────────────────────────────────────────────────────────────────────────────
# HL7 Trennzeichen
# ────────────────────────────────────────────────────────────────────────────────
FS, CS, RS, ES, SC = "|", "^", "~", "\\", "&"
SEG = "\r"
ENC = f"{CS}{RS}{ES}{SC}"

MLLP_START = "\x0b"
MLLP_END   = "\x1c\x0d"


# ────────────────────────────────────────────────────────────────────────────────
# Datenklassen
# ────────────────────────────────────────────────────────────────────────────────
@dataclass
class Kasse:
    ik: str
    kurzname: str
    langname: str
    strasse: str
    plz: str
    ort: str
    art: str = "GKV"           # GKV, PKV, BG

@dataclass
class Arzt:
    id: str
    nachname: str
    vorname: str
    titel: str = ""
    fachbezeichnung: str = ""

@dataclass
class Hausarzt:
    lanr: str                  # Lebenslange Arztnummer
    bsnr: str                  # Betriebsstättennummer
    nachname: str
    vorname: str
    titel: str
    strasse: str
    plz: str
    ort: str
    telefon: str
    praxis_name: str

@dataclass
class Angehoeriger:
    nachname: str
    vorname: str
    beziehung: str             # HL7 0063: SPO, MTH, FTH, CHD, BRO, SIS, PAR, OTH
    beziehung_text: str
    strasse: str
    plz: str
    ort: str
    telefon: str
    mobil: str
    kontakt_rolle: str = "EP"  # HL7 0131: EP=Emergency Contact, CP=Contact Person

@dataclass
class Allergie:
    code: str                  # hauseigener Kürzel
    text: str
    typ: str                   # HL7 0127: DA=Drug, FA=Food, EA=Environmental, AA=Animal, LA=Latex, MA=Miscellaneous
    typ_text: str
    schwere: str               # HL7 0128: SV=severe, MO=moderate, MI=mild, U=unknown
    reaktion: str

@dataclass
class Diagnose:
    icd: str
    text: str
    art: str = "HD"            # §301: HD / ND
    sicherheit: str = "G"      # G gesichert, V Verdacht, A ausgeschlossen, Z Zustand nach
    seite: str = ""            # R, L, B

@dataclass
class Koerpermass:
    groesse_cm: float
    gewicht_kg: float
    rr_sys_mmhg: int
    rr_dia_mmhg: int
    puls_min: int
    temperatur_c: float

@dataclass
class Patient:
    pid: str
    nachname: str
    vorname: str
    titel: str
    geburtsname: str
    geburtsdatum: str          # YYYYMMDD
    geschlecht: str            # M, F, A, U
    strasse: str
    plz: str
    ort: str
    land: str                  # ISO 3166 3-stellig
    geburtsort: str
    tel_privat: str
    tel_mobil: str
    email: str
    staatsangehoerigkeit: str
    familienstand: str         # HL7 0002
    konfession: str            # HL7 0006
    beruf: str
    arbeitgeber: str
    versicherten_nr: str
    kasse: Kasse

@dataclass
class Einrichtung:
    oid: str
    name_kurz: str
    name_lang: str
    strasse: str
    plz: str
    ort: str
    ik: str
    telefon: str

@dataclass
class Szenario:
    key: str
    titel: str
    fachabteilung_code: str    # §301 4-stellig, z.B. "0103"
    fachabteilung_kurz: str
    fachabteilung_lang: str
    aufnahme_station: str
    zimmer: str
    bett: str
    aufnahmeanlass: str        # §301: E Einweisung, N Notfall, V Verlegung, A Aufnahme nach vorstationärer Behandlung
    aufnahmegrund: str         # §301 4-stellig, z.B. "0101" (Vollstationär)
    hauptdiagnose: Diagnose
    nebendiagnosen: List[Diagnose]
    allergien: List[Allergie]
    durchschn_verweildauer_tage: int
    entlassungsgrund: str = "019"  # §301 3-stellig: 01 regulär, 07 Tod, 09 Verlegung
    patient_class: str = "I"       # HL7 0004: I Inpatient, O Outpatient, E Emergency, P Preadmit
    verlegungen: List[Tuple[str, str, str]] = field(default_factory=list)
    # Verlegungen als (station, zimmer, bett) Tupel – für Chain-Modus

@dataclass
class Fall:
    fallnummer: str
    aufnahme: datetime
    entlassung: datetime
    patient: Patient
    szenario: Szenario
    aufnehmender: Arzt
    behandelnder: Arzt
    entlassender: Arzt
    hausarzt: Hausarzt
    angehoeriger: Angehoeriger
    einrichtung: Einrichtung
    koerpermass: Koerpermass
    aktuelle_location: Tuple[str, str, str]  # (station, zimmer, bett)
    vorherige_location: Optional[Tuple[str, str, str]] = None


# ────────────────────────────────────────────────────────────────────────────────
# Stammdaten
# ────────────────────────────────────────────────────────────────────────────────
EINRICHTUNG = Einrichtung(
    oid="1.2.276.0.76.4.17.9999",
    name_kurz="KLINIKUM-MUC",
    name_lang="Städtisches Klinikum München-Schwabing",
    strasse="Kölner Platz 1",
    plz="80804",
    ort="München",
    ik="260914000",
    telefon="+49-89-3068-0",
)

KASSEN: List[Kasse] = [
    Kasse("108018007", "TK",      "Techniker Krankenkasse",            "Bramfelder Str. 140",  "22305", "Hamburg"),
    Kasse("108310400", "BARMER",  "BARMER",                            "Axel-Springer-Str. 44","10969", "Berlin"),
    Kasse("101575519", "DAK",     "DAK-Gesundheit",                    "Nagelsweg 27-31",      "20097", "Hamburg"),
    Kasse("108433248", "AOK-BAY", "AOK Bayern – Die Gesundheitskasse", "Carl-Wery-Str. 28",    "81739", "München"),
    Kasse("107202793", "IKK-CL",  "IKK classic",                       "Tannenstr. 4b",        "01099", "Dresden"),
    Kasse("109905003", "KBS",     "Knappschaft-Bahn-See",              "Pieperstr. 14-28",     "44789", "Bochum"),
    Kasse("105313145", "HKK",     "hkk Krankenkasse",                  "Martinistr. 26",       "28195", "Bremen"),
]

AERZTE: List[Arzt] = [
    Arzt("10023", "Schmidt",  "Werner",  "Dr. med.",       "Kardiologie"),
    Arzt("10045", "Weber",    "Ingrid",  "Dr. med.",       "Innere Medizin"),
    Arzt("10087", "Huber",    "Martin",  "Prof. Dr. med.", "Unfallchirurgie"),
    Arzt("10102", "Bauer",    "Sabine",  "Dr. med.",       "Viszeralchirurgie"),
    Arzt("10134", "Fischer",  "Klaus",   "Dr. med.",       "Gastroenterologie"),
    Arzt("10158", "Wagner",   "Petra",   "Dr. med.",       "Onkologie"),
    Arzt("10171", "Becker",   "Thomas",  "Dr. med.",       "Pneumologie"),
    Arzt("10199", "Hoffmann", "Elke",    "Dr. med.",       "Anästhesie"),
    Arzt("10215", "Schulz",   "Andreas", "PD Dr. med.",    "Nephrologie"),
    Arzt("10247", "Koch",     "Monika",  "Dr. med.",       "Orthopädie"),
    Arzt("10258", "Richter",  "Dieter",  "Dr. med.",       "Neurologie"),
]

HAUSAERZTE: List[Hausarzt] = [
    Hausarzt("123456789", "887766655", "Gruber",   "Thomas",  "Dr. med.",
             "Marienplatz 4",          "80331", "München", "+49-89-23000123", "Praxis Dr. Gruber"),
    Hausarzt("234567890", "887766656", "Meier",    "Elisabeth","Dr. med.",
             "Sendlinger Str. 33",     "80331", "München", "+49-89-23000456", "Gemeinschaftspraxis Meier/Hahn"),
    Hausarzt("345678901", "887766657", "Lindner",  "Franz",   "Dr. med.",
             "Bavariaring 19",         "80336", "München", "+49-89-23000789", "Hausärztliche Internisten München"),
    Hausarzt("456789012", "887766658", "Stark",    "Anna",    "Dr. med.",
             "Hohenzollernstr. 85",    "80796", "München", "+49-89-23000234", "MVZ Schwabing"),
    Hausarzt("567890123", "887766659", "Kaiser",   "Matthias","Dr. med.",
             "Rotkreuzplatz 8",        "80634", "München", "+49-89-23000567", "Facharztpraxis Dr. Kaiser"),
]

ALLERGENE: List[Allergie] = [
    Allergie("PEN",    "Penicillin",               "DA", "Medikamentenallergie",   "SV", "Anaphylaxie, Atemnot, Exanthem"),
    Allergie("ASS",    "Acetylsalicylsäure",       "DA", "Medikamentenallergie",   "MO", "Urtikaria, Bronchospasmus"),
    Allergie("KM",     "Jodhaltiges Kontrastmittel","DA","Medikamentenallergie",  "SV", "Anaphylaktoide Reaktion Grad III"),
    Allergie("SULF",   "Sulfonamide",              "DA", "Medikamentenallergie",   "MO", "Makulopapulöses Exanthem"),
    Allergie("LATEX",  "Latex",                    "LA", "Latexallergie",          "MO", "Kontaktdermatitis, Schleimhautödem"),
    Allergie("ERDNUSS","Erdnuss",                  "FA", "Nahrungsmittelallergie", "SV", "Anaphylaxie"),
    Allergie("LAKTOSE","Laktose",                  "FA", "Nahrungsmittelintoleranz","MI","Meteorismus, Diarrhö"),
    Allergie("HAUSSTB","Hausstaubmilben",          "EA", "Umweltallergen",         "MI", "Rhinokonjunktivitis"),
    Allergie("POLLEN", "Gräserpollen",             "EA", "Umweltallergen",         "MI", "Allergische Rhinitis"),
    Allergie("KATZE",  "Katzenepithelien",         "AA", "Tierallergen",           "MO", "Asthma bronchiale, Rhinitis"),
]

VORNAMEN_M = ["Hans","Peter","Michael","Thomas","Wolfgang","Klaus","Günther",
              "Stefan","Andreas","Josef","Franz","Heinrich","Bernhard","Dieter","Helmut"]
VORNAMEN_F = ["Maria","Ursula","Brigitte","Renate","Monika","Helga","Gisela",
              "Ingrid","Christa","Elisabeth","Karin","Hannelore","Waltraud","Inge","Erika"]
NACHNAMEN  = ["Müller","Schmidt","Schneider","Fischer","Meyer","Weber","Wagner",
              "Becker","Hoffmann","Schäfer","Koch","Bauer","Richter","Klein",
              "Wolf","Schröder","Neumann","Schwarz","Zimmermann","Braun","Krüger","Hartmann"]
STRASSEN   = [("Hauptstraße","81667","München"),("Leopoldstraße","80802","München"),
              ("Lindwurmstraße","80337","München"),("Schleißheimer Str.","80797","München"),
              ("Rosenheimer Str.","81669","München"),("Fürstenrieder Str.","80686","München"),
              ("Dachauer Str.","80335","München"),("Tegernseer Landstr.","81541","München"),
              ("Ingolstädter Str.","85055","Ingolstadt"),("Bahnhofstr.","82166","Gräfelfing")]

BERUFE = ["Angestellte/r","Rentner/in","Selbstständig","Facharbeiter/in",
          "Lehrer/in","Ingenieur/in","Kauffrau/-mann","Hausfrau/-mann",
          "Arzt/Ärztin","Pflegekraft","Student/in","Handwerker/in"]


# ────────────────────────────────────────────────────────────────────────────────
# Szenarien
# ────────────────────────────────────────────────────────────────────────────────
SZENARIEN: List[Szenario] = [
    Szenario(
        key="kardio",
        titel="Akuter Myokardinfarkt",
        fachabteilung_code="0103", fachabteilung_kurz="KAR", fachabteilung_lang="Kardiologie",
        aufnahme_station="CPU-1", zimmer="101", bett="1",
        aufnahmeanlass="N", aufnahmegrund="0101",
        hauptdiagnose=Diagnose("I21.4", "Akuter subendokardialer Myokardinfarkt", "HD"),
        nebendiagnosen=[
            Diagnose("I10.90", "Essentielle Hypertonie, nicht näher bezeichnet", "ND"),
            Diagnose("E78.0",  "Reine Hypercholesterinämie", "ND"),
        ],
        allergien=[ALLERGENE[0], ALLERGENE[2]],  # Penicillin, Kontrastmittel
        durchschn_verweildauer_tage=7,
        verlegungen=[("KAR-3A", "312", "1"), ("KAR-REHA", "205", "2")],
    ),
    Szenario(
        key="ortho",
        titel="Hüft-TEP bei Coxarthrose",
        fachabteilung_code="1500", fachabteilung_kurz="ORT", fachabteilung_lang="Orthopädie/Unfallchirurgie",
        aufnahme_station="ORT-2B", zimmer="205", bett="2",
        aufnahmeanlass="E", aufnahmegrund="0101",
        hauptdiagnose=Diagnose("M16.1", "Sonstige primäre Koxarthrose", "HD", "G", "R"),
        nebendiagnosen=[
            Diagnose("E66.01","Adipositas Grad I, BMI 30-35", "ND"),
            Diagnose("I10.90","Essentielle Hypertonie, n.n.b.", "ND"),
        ],
        allergien=[ALLERGENE[1]],
        durchschn_verweildauer_tage=10,
        verlegungen=[("ORT-REHA", "310", "1")],
    ),
    Szenario(
        key="gastro",
        titel="Laparoskopische Cholezystektomie",
        fachabteilung_code="1500", fachabteilung_kurz="VIS", fachabteilung_lang="Allgemein- und Viszeralchirurgie",
        aufnahme_station="CHI-1A", zimmer="114", bett="1",
        aufnahmeanlass="E", aufnahmegrund="0101",
        hauptdiagnose=Diagnose("K80.20","Gallenblasenstein ohne Cholezystitis, ohne Obstruktion","HD"),
        nebendiagnosen=[Diagnose("K29.70","Gastritis, n.n.b.","ND")],
        allergien=[],
        durchschn_verweildauer_tage=4,
        verlegungen=[],
    ),
    Szenario(
        key="trauma",
        titel="Polytrauma nach Verkehrsunfall",
        fachabteilung_code="1600", fachabteilung_kurz="UNF", fachabteilung_lang="Unfallchirurgie",
        aufnahme_station="SCHOCK", zimmer="SR1", bett="1",
        aufnahmeanlass="N", aufnahmegrund="0103",
        hauptdiagnose=Diagnose("T06.8","Sonstige näher bezeichnete Verletzungen mit Beteiligung mehrerer Körperregionen","HD"),
        nebendiagnosen=[
            Diagnose("S06.0","Commotio cerebri", "ND"),
            Diagnose("S22.40","Serienfraktur der Rippen, nicht näher bezeichnet","ND"),
            Diagnose("S72.00","Fraktur des Femurhalses, n.n.b.","ND","G","L"),
        ],
        allergien=[],
        durchschn_verweildauer_tage=18,
        verlegungen=[("UNF-ITS", "301", "2"), ("UNF-2A", "210", "1")],
    ),
    Szenario(
        key="onko",
        titel="Chemotherapie bei Mamma-Ca",
        fachabteilung_code="0200", fachabteilung_kurz="ONK", fachabteilung_lang="Hämatologie/Onkologie",
        aufnahme_station="ONK-4A", zimmer="408", bett="1",
        aufnahmeanlass="E", aufnahmegrund="0102",  # teilstationär
        patient_class="I",
        hauptdiagnose=Diagnose("C50.4","Bösartige Neubildung: Oberer äußerer Quadrant der Brust","HD","G","L"),
        nebendiagnosen=[
            Diagnose("Z51.1","Chemotherapie-Sitzung wegen bösartiger Neubildung","ND"),
            Diagnose("D64.9","Anämie, n.n.b.", "ND"),
        ],
        allergien=[ALLERGENE[0], ALLERGENE[5]],
        durchschn_verweildauer_tage=3,
        verlegungen=[],
    ),
    Szenario(
        key="infekt",
        titel="Schwere Pneumonie, V. a. Sepsis",
        fachabteilung_code="0800", fachabteilung_kurz="PNE", fachabteilung_lang="Pneumologie",
        aufnahme_station="PNE-ITS", zimmer="IMC1", bett="1",
        aufnahmeanlass="N", aufnahmegrund="0101",
        hauptdiagnose=Diagnose("J18.1","Lobärpneumonie, nicht näher bezeichnet","HD"),
        nebendiagnosen=[
            Diagnose("A41.9","Sepsis, n.n.b.", "ND"),
            Diagnose("J96.01","Akute respiratorische Insuffizienz, Typ I","ND"),
        ],
        allergien=[ALLERGENE[0]],
        durchschn_verweildauer_tage=12,
        verlegungen=[("PNE-2C", "223", "3")],
    ),
    Szenario(
        key="ambulant",
        titel="Ambulante OP: Arthroskopie Knie",
        fachabteilung_code="1500", fachabteilung_kurz="AOP", fachabteilung_lang="Ambulantes OP-Zentrum",
        aufnahme_station="AOP-1", zimmer="A1", bett="1",
        aufnahmeanlass="A", aufnahmegrund="0104",
        patient_class="O",
        hauptdiagnose=Diagnose("M23.20","Meniskusschaden, Innenmeniskus","HD","G","R"),
        nebendiagnosen=[],
        allergien=[],
        durchschn_verweildauer_tage=0,
        entlassungsgrund="011",
        verlegungen=[],
    ),
]


# ────────────────────────────────────────────────────────────────────────────────
# HL7 Helpers
# ────────────────────────────────────────────────────────────────────────────────
def hl7_escape(v) -> str:
    if v is None:
        return ""
    s = str(v)
    return (s.replace(ES, rf"{ES}E{ES}")
             .replace(FS, rf"{ES}F{ES}")
             .replace(CS, rf"{ES}S{ES}")
             .replace(RS, rf"{ES}R{ES}")
             .replace(SC, rf"{ES}T{ES}"))

def ts(dt: datetime, precision: str = "S") -> str:
    fmts = {"D":"%Y%m%d","M":"%Y%m%d%H%M","H":"%Y%m%d%H","S":"%Y%m%d%H%M%S"}
    return dt.strftime(fmts.get(precision,"%Y%m%d%H%M%S"))

def comp(*parts) -> str:
    r = [str(p) if p is not None else "" for p in parts]
    while r and r[-1] == "":
        r.pop()
    return CS.join(r)

def repeat(*fields) -> str:
    return RS.join(f for f in fields if f)

def seg(*fields) -> str:
    r = [f if f is not None else "" for f in fields]
    while len(r) > 1 and r[-1] == "":
        r.pop()
    return FS.join(r)

def arzt_xcn(a: Arzt, e: Einrichtung) -> str:
    """XCN – Extended Composite ID Number and Name for Persons."""
    return (f"{a.id}{CS}{hl7_escape(a.nachname)}{CS}{hl7_escape(a.vorname)}"
            f"{CS}{CS}{CS}{hl7_escape(a.titel)}{CS}{CS}{CS}"
            f"{e.name_kurz}&{e.ik}&DE-IK")

def location_pl(station: str, zimmer: str, bett: str, e: Einrichtung,
                sz: Szenario) -> str:
    """PL – Person Location."""
    return (f"{station}{CS}{zimmer}{CS}{bett}{CS}"
            f"{e.name_kurz}&{e.ik}&DE-IK{CS}{CS}{sz.fachabteilung_kurz}")


# ────────────────────────────────────────────────────────────────────────────────
# Segment-Builder
# ────────────────────────────────────────────────────────────────────────────────
def build_msh(trigger: str, msg_struct: str, msg_ctrl_id: str,
              now: datetime, e: Einrichtung) -> str:
    return (f"MSH{FS}{ENC}{FS}"
            f"health-engine^{e.oid}^ISO{FS}"
            f"{e.name_kurz}^{e.ik}^DE-IK{FS}"
            f"KIS-EMPFAENGER^1.2.276.0.76.4.17.8888^ISO{FS}"
            f"ZIELSYSTEM^260914777^DE-IK{FS}"
            f"{ts(now)}{FS}{FS}"
            f"ADT{CS}{trigger}{CS}{msg_struct}{FS}"
            f"{msg_ctrl_id}{FS}"
            f"P{FS}2.5{FS}{FS}{FS}AL{FS}NE{FS}DEU{FS}UNICODE UTF-8{FS}de-DE")

def build_evn(event: str, occurred: datetime, recorded: datetime,
              reason_code: str, reason_text: str, operator: Arzt,
              e: Einrichtung) -> str:
    return seg("EVN",
        event,                                        # EVN-1 Event Type Code
        ts(recorded),                                 # EVN-2 Recorded Date/Time
        "",                                           # EVN-3 Planned Date/Time
        f"{reason_code}{CS}{hl7_escape(reason_text)}{CS}L",  # EVN-4 Event Reason
        arzt_xcn(operator, e),                        # EVN-5 Operator ID
        ts(occurred),                                 # EVN-6 Event Occurred
        f"{e.name_kurz}{CS}{e.ik}{CS}DE-IK",          # EVN-7 Event Facility
    )

def build_pid(p: Patient, e: Einrichtung, fall: Fall) -> str:
    name = (f"{hl7_escape(p.nachname)}{CS}{hl7_escape(p.vorname)}"
            f"{CS}{CS}{CS}{hl7_escape(p.titel)}{CS}{CS}L")
    geb_name = (f"{hl7_escape(p.geburtsname)}{CS}{CS}{CS}{CS}{CS}{CS}M"
                if p.geburtsname else "")
    namen = repeat(name, geb_name) if geb_name else name

    ids = repeat(
        f"{p.pid}{CS}{CS}{CS}{e.name_kurz}{CS}MR{CS}{e.name_kurz}",
        f"{p.versicherten_nr}{CS}{CS}{CS}{p.kasse.ik}&{p.kasse.kurzname}&DE-IK{CS}NH",
    )
    adr = (f"{hl7_escape(p.strasse)}{CS}{CS}{hl7_escape(p.ort)}{CS}BY{CS}"
           f"{p.plz}{CS}{p.land}{CS}H")

    return seg("PID",
        "1",                                          # PID-1 Set ID
        "",                                           # PID-2 (deprecated)
        ids,                                          # PID-3 Patient Identifier List
        "",                                           # PID-4 (deprecated)
        namen,                                        # PID-5 Patient Name
        (f"{hl7_escape(p.geburtsname)}{CS}{CS}{CS}{CS}{CS}{CS}M"
         if p.geburtsname else ""),                   # PID-6 Mother's Maiden Name
        p.geburtsdatum,                               # PID-7 Date/Time of Birth
        p.geschlecht,                                 # PID-8 Administrative Sex
        "",                                           # PID-9 (deprecated)
        "",                                           # PID-10 Race
        adr,                                          # PID-11 Address
        "",                                           # PID-12 County Code
        f"{p.tel_privat}{CS}PRN{CS}PH",               # PID-13 Phone Home
        (f"{p.tel_mobil}{CS}ORN{CS}CP"
         f"{RS}{p.email}{CS}NET{CS}Internet"),        # PID-14 Phone Business
        "de-DE",                                      # PID-15 Primary Language
        p.familienstand,                              # PID-16 Marital Status
        p.konfession,                                 # PID-17 Religion
        fall.fallnummer,                              # PID-18 Patient Account Number
        "",                                           # PID-19 SSN
        "",                                           # PID-20 Driver License
        "",                                           # PID-21 Mother's Identifier
        "",                                           # PID-22 Ethnic Group
        hl7_escape(p.geburtsort),                     # PID-23 Birth Place
        "N",                                          # PID-24 Multiple Birth Indicator
        "",                                           # PID-25 Birth Order
        p.staatsangehoerigkeit,                       # PID-26 Citizenship
        "",                                           # PID-27 Veterans Military Status
        p.staatsangehoerigkeit,                       # PID-28 Nationality
        "",                                           # PID-29 Patient Death Date/Time
        "N",                                          # PID-30 Patient Death Indicator
        "N",                                          # PID-31 Identity Unknown
    )

def build_pd1(p: Patient, hausarzt: Hausarzt) -> str:
    """PD1 – Patient Additional Demographic. Wichtigster Inhalt: Hausarzt (PD1-4)."""
    hausarzt_xon = (f"{hl7_escape(hausarzt.praxis_name)}{CS}{CS}{hausarzt.bsnr}"
                    f"{CS}{CS}{CS}{CS}BSNR{CS}{CS}{CS}{hausarzt.bsnr}")
    hausarzt_xcn = (f"{hausarzt.lanr}{CS}{hl7_escape(hausarzt.nachname)}"
                    f"{CS}{hl7_escape(hausarzt.vorname)}{CS}{CS}{CS}"
                    f"{hl7_escape(hausarzt.titel)}{CS}{CS}{CS}"
                    f"{hausarzt.bsnr}&LANR&DE-LANR")
    return seg("PD1",
        "",                                           # PD1-1 Living Dependency
        "A",                                          # PD1-2 Living Arrangement (A=Alone)
        hausarzt_xon,                                 # PD1-3 Patient Primary Facility
        hausarzt_xcn,                                 # PD1-4 Patient Primary Care Provider
        "",                                           # PD1-5 Student Indicator
        "",                                           # PD1-6 Handicap
        "Y",                                          # PD1-7 Living Will
        "N",                                          # PD1-8 Organ Donor
        "N",                                          # PD1-9 Separate Bill
        "",                                           # PD1-10 Duplicate Patient
        f"NOPUBL{CS}Keine Veröffentlichung{CS}HL70215",  # PD1-11 Publicity Code
        "N",                                          # PD1-12 Protection Indicator
        "",                                           # PD1-13 Protection Indicator Effective Date
        "",                                           # PD1-14 Place of Worship
    )

def build_nk1(nr: int, ang: Angehoeriger, p: Patient) -> str:
    name = (f"{hl7_escape(ang.nachname)}{CS}{hl7_escape(ang.vorname)}"
            f"{CS}{CS}{CS}{CS}{CS}L")
    adr = (f"{hl7_escape(ang.strasse)}{CS}{CS}{hl7_escape(ang.ort)}{CS}BY{CS}"
           f"{ang.plz}{CS}DEU{CS}H")
    return seg("NK1",
        str(nr),                                      # NK1-1 Set ID
        name,                                         # NK1-2 Name
        f"{ang.beziehung}{CS}{hl7_escape(ang.beziehung_text)}{CS}HL70063",
        adr,                                          # NK1-4 Address
        f"{ang.telefon}{CS}PRN{CS}PH"
            f"{RS}{ang.mobil}{CS}ORN{CS}CP",          # NK1-5 Phone
        "",                                           # NK1-6 Business Phone
        f"{ang.kontakt_rolle}{CS}Notfallkontakt{CS}HL70131",  # NK1-7 Contact Role
        "",                                           # NK1-8 Start Date
        "",                                           # NK1-9 End Date
        "",                                           # NK1-10 Job Title
        "",                                           # NK1-11 Job Code/Class
        "",                                           # NK1-12 Employee Number
        "",                                           # NK1-13 Organization Name
        "",                                           # NK1-14 Marital Status
        "",                                           # NK1-15 Sex
    )

def build_pv1(fall: Fall, mode: str = "admit") -> str:
    """mode: admit | transfer | discharge | cancel | preadmit | outpatient | current"""
    e, sz = fall.einrichtung, fall.szenario
    st, zi, be = fall.aktuelle_location
    loc = location_pl(st, zi, be, e, sz)

    prior_loc = ""
    if fall.vorherige_location and mode in ("transfer", "current"):
        pst, pzi, pbe = fall.vorherige_location
        prior_loc = location_pl(pst, pzi, pbe, e, sz)

    # Bei Entlassung: Entlasszeit + Disposition füllen
    entlass_ts = ts(fall.entlassung) if mode == "discharge" else ""
    entlass_disp = sz.entlassungsgrund if mode == "discharge" else ""
    patient_class = sz.patient_class if mode != "preadmit" else "P"

    return seg("PV1",
        "1",                                          # PV1-1 Set ID
        patient_class,                                # PV1-2 Patient Class
        loc,                                          # PV1-3 Assigned Patient Location
        sz.aufnahmeanlass,                            # PV1-4 Admission Type
        fall.fallnummer,                              # PV1-5 Preadmit Number
        prior_loc,                                    # PV1-6 Prior Patient Location
        arzt_xcn(fall.aufnehmender, e),               # PV1-7 Attending Doctor
        arzt_xcn(fall.behandelnder, e),               # PV1-8 Referring Doctor
        arzt_xcn(fall.behandelnder, e),               # PV1-9 Consulting Doctor
        sz.fachabteilung_kurz,                        # PV1-10 Hospital Service
        "",                                           # PV1-11 Temporary Location
        "",                                           # PV1-12 Preadmit Test Indicator
        "",                                           # PV1-13 Re-Admission Indicator
        sz.aufnahmeanlass,                            # PV1-14 Admit Source
        "",                                           # PV1-15 Ambulatory Status
        "N",                                          # PV1-16 VIP Indicator
        arzt_xcn(fall.aufnehmender, e),               # PV1-17 Admitting Doctor
        "AKU",                                        # PV1-18 Patient Type
        fall.fallnummer,                              # PV1-19 Visit Number
        f"GKV{CS}Gesetzliche Krankenversicherung{CS}DE-KV",  # PV1-20 Financial Class
        *([""] * 15),                                 # PV1-21 … PV1-35
        entlass_disp,                                 # PV1-36 Discharge Disposition
        "",                                           # PV1-37 Discharged to Location
        "",                                           # PV1-38 Diet Type
        f"{e.name_kurz}{CS}{e.ik}{CS}DE-IK",          # PV1-39 Servicing Facility
        "",                                           # PV1-40 Bed Status
        "AKUT",                                       # PV1-41 Account Status
        "",                                           # PV1-42 Pending Location
        prior_loc,                                    # PV1-43 Prior Temporary Location
        ts(fall.aufnahme),                            # PV1-44 Admit Date/Time
        entlass_ts,                                   # PV1-45 Discharge Date/Time
        "",                                           # PV1-46 Current Patient Balance
        "",                                           # PV1-47 Total Charges
        "",                                           # PV1-48 Total Adjustments
        "",                                           # PV1-49 Total Payments
        "",                                           # PV1-50 Alternate Visit ID
        "A",                                          # PV1-51 Visit Indicator
    )

def build_pv2(fall: Fall, mode: str = "admit") -> str:
    sz = fall.szenario
    zeitraum_start = ts(fall.aufnahme, "D")
    zeitraum_ende  = ts(fall.entlassung, "D")
    erwartete_vwd  = str(sz.durchschn_verweildauer_tage)
    actual_vwd     = str((fall.entlassung - fall.aufnahme).days) if mode == "discharge" else ""

    return seg("PV2",
        "",                                           # PV2-1 Prior Pending Location
        "",                                           # PV2-2 Accommodation Code
        f"{sz.aufnahmegrund}{CS}{hl7_escape(sz.hauptdiagnose.text)}{CS}§301-AG",
        f"{sz.hauptdiagnose.icd}{CS}{hl7_escape(sz.hauptdiagnose.text)}{CS}ICD-10-GM",
        "",                                           # PV2-5 Transfer Reason
        "",                                           # PV2-6 Patient Valuables
        "",                                           # PV2-7 Patient Valuables Location
        "RO",                                         # PV2-8 Visit User Code (Routine)
        zeitraum_start,                               # PV2-9 Expected Admit Date/Time
        zeitraum_ende,                                # PV2-10 Expected Discharge Date/Time
        erwartete_vwd,                                # PV2-11 Estimated Length of Inpatient Stay
        actual_vwd,                                   # PV2-12 Actual Length of Inpatient Stay
        hl7_escape(f"Aufnahmegrund {sz.aufnahmegrund} – {sz.titel}"),
        "",                                           # PV2-14 Referral Source Code
        "",                                           # PV2-15 Previous Service Date
        "N",                                          # PV2-16 Employment Illness Related
        sz.entlassungsgrund if mode == "discharge" else "",  # PV2-17 Visit Patient Status
        "P",                                          # PV2-18 Visit Priority
        "",                                           # PV2-19 Previous Treatment Date
        "",                                           # PV2-20 Expected Discharge Disposition
        "",                                           # PV2-21 Signature on File Date
        "",                                           # PV2-22 First Similar Illness Date
        "",                                           # PV2-23 Patient Charge Adjustment Code
        "",                                           # PV2-24 Recurring Service
        "N",                                          # PV2-25 Billing Media Code
        "",                                           # PV2-26 Expected Surgery Date/Time
        "N",                                          # PV2-27 Military Partnership Code
        "N",                                          # PV2-28 Military Non-Availability Code
        "N",                                          # PV2-29 Newborn Baby Indicator
        "N",                                          # PV2-30 Baby Detained Indicator
    )

def build_obx_vitals(start_idx: int, km: Koerpermass,
                     when: datetime, e: Einrichtung) -> List[str]:
    """OBX-Segmente für Aufnahme-Vitalparameter (Größe, Gewicht, RR, Puls, Temp)."""
    def one(idx, loinc, name, value, unit, ref):
        return seg("OBX",
            str(idx), "NM",
            f"{loinc}{CS}{hl7_escape(name)}{CS}LN",
            "1",                                      # Sub-ID
            str(value),
            f"{unit}{CS}{unit}{CS}UCUM" if unit else "",
            ref,                                      # Ref range (optional)
            "N",                                      # Flag
            "", "", "F", "", "",
            ts(when),
            f"{e.name_kurz}{CS}{e.ik}{CS}DE-IK",
        )
    bmi = km.gewicht_kg / ((km.groesse_cm / 100) ** 2)
    return [
        one(start_idx,   "8302-2",  "Körpergröße",         f"{km.groesse_cm:.0f}",        "cm",    "—"),
        one(start_idx+1, "29463-7", "Körpergewicht",        f"{km.gewicht_kg:.1f}",        "kg",    "—"),
        one(start_idx+2, "39156-5", "Body-Mass-Index",      f"{bmi:.1f}",                  "kg/m2", "18.5 - 24.9"),
        one(start_idx+3, "8480-6",  "RR systolisch",        f"{km.rr_sys_mmhg}",           "mm[Hg]","90 - 139"),
        one(start_idx+4, "8462-4",  "RR diastolisch",       f"{km.rr_dia_mmhg}",           "mm[Hg]","60 - 89"),
        one(start_idx+5, "8867-4",  "Herzfrequenz",         f"{km.puls_min}",              "/min",  "50 - 100"),
        one(start_idx+6, "8310-5",  "Körpertemperatur",     f"{km.temperatur_c:.1f}",      "Cel",   "36.2 - 37.5"),
    ]

def build_al1(nr: int, a: Allergie, onset: Optional[datetime] = None) -> str:
    return seg("AL1",
        str(nr),                                      # AL1-1 Set ID
        f"{a.typ}{CS}{hl7_escape(a.typ_text)}{CS}HL70127",   # AL1-2 Allergen Type
        f"{a.code}{CS}{hl7_escape(a.text)}{CS}L",     # AL1-3 Allergen Code/Mnemonic
        f"{a.schwere}{CS}"
            + {'SV':'schwer','MO':'moderat','MI':'leicht','U':'unbekannt'}.get(a.schwere, '')
            + f"{CS}HL70128",                         # AL1-4 Severity
        hl7_escape(a.reaktion),                       # AL1-5 Reaction
        ts(onset, "D") if onset else "",              # AL1-6 Identification Date
    )

def build_dg1(nr: int, d: Diagnose, behandelnder: Arzt,
              fall: Fall, drg: str = "", drg_text: str = "") -> str:
    drg_ce = f"{drg}{CS}{hl7_escape(drg_text)}{CS}DRG-2026" if drg else ""
    clinician = (f"{behandelnder.id}{CS}{hl7_escape(behandelnder.nachname)}"
                 f"{CS}{hl7_escape(behandelnder.vorname)}{CS}{CS}{CS}"
                 f"{hl7_escape(behandelnder.titel)}")
    return seg("DG1",
        str(nr),
        "ICD-10-GM-2026",
        f"{d.icd}{CS}{hl7_escape(d.text)}{CS}ICD-10-GM{CS}{CS}{CS}2026",
        "",
        ts(fall.aufnahme),
        "A" if d.art == "HD" else "W",
        "",
        drg_ce,
        "Y" if drg else "",
        "", "", "", "",
        "V2026",
        str(nr),
        clinician,
        d.art,
        "N",
        ts(fall.entlassung) if fall.entlassung else "",
        f"DG-{fall.fallnummer}-{nr:02d}{CS}{CS}{fall.einrichtung.name_kurz}{CS}AN",
        "A",
    )

def build_gt1(p: Patient, fall: Fall) -> str:
    name = (f"{hl7_escape(p.nachname)}{CS}{hl7_escape(p.vorname)}"
            f"{CS}{CS}{CS}{hl7_escape(p.titel)}{CS}{CS}L")
    adr = (f"{hl7_escape(p.strasse)}{CS}{CS}{hl7_escape(p.ort)}{CS}BY{CS}"
           f"{p.plz}{CS}{p.land}{CS}H")
    return seg("GT1",
        "1", f"GT-{fall.fallnummer}", name, "", adr,
        f"{p.tel_privat}{CS}PRN{CS}PH",
        f"{p.tel_mobil}{CS}ORN{CS}CP",
        p.geburtsdatum, p.geschlecht, "SEL", "", "",
        ts(fall.aufnahme, "D"), "", "1", hl7_escape(p.arbeitgeber),
        "", "", "", "F", "P", p.staatsangehoerigkeit,
    )

def build_in1(p: Patient, fall: Fall) -> str:
    k = p.kasse
    kasse_adr = (f"{hl7_escape(k.strasse)}{CS}{CS}{hl7_escape(k.ort)}{CS}{CS}"
                 f"{k.plz}{CS}DEU{CS}B")
    name_ins = (f"{hl7_escape(p.nachname)}{CS}{hl7_escape(p.vorname)}"
                f"{CS}{CS}{CS}{hl7_escape(p.titel)}{CS}{CS}L")
    pat_adr = (f"{hl7_escape(p.strasse)}{CS}{CS}{hl7_escape(p.ort)}{CS}BY{CS}"
               f"{p.plz}{CS}{p.land}")
    return seg("IN1",
        "1",
        f"{k.art}{CS}Gesetzliche Krankenversicherung{CS}DE-KV",
        f"{k.ik}{CS}{CS}{CS}DE-IK",
        hl7_escape(k.langname),
        kasse_adr,
        "", "",
        f"GRP-{k.kurzname}-01",
        f"{hl7_escape(k.langname)} – Versichertenkollektiv",
        "", "",
        ts(datetime(fall.aufnahme.year, 1, 1), "D"),
        ts(datetime(fall.aufnahme.year, 12, 31), "D"),
        "", "V1", name_ins, "SEL", p.geburtsdatum, pat_adr,
        "0", "", "1", *([""] * 3), "N", *([""] * 3), "SL", "CR",
        *([""] * 2), "SL", f"POL-{p.versicherten_nr}", "0.00", *([""] * 4),
        f"0001{CS}Mitglied{CS}DE-KV", p.geschlecht, pat_adr, "", "01", "V", "",
        f"{p.versicherten_nr}{CS}{CS}{CS}{k.ik}&{k.kurzname}&DE-IK{CS}NH",
    )

def build_mrg(old_pid: str, old_patient: Patient,
              e: Einrichtung, old_fall: Optional[str] = None) -> str:
    """MRG – Merge Patient Information. Verweis auf die aufzugebende PID."""
    prior_name = (f"{hl7_escape(old_patient.nachname)}{CS}"
                  f"{hl7_escape(old_patient.vorname)}{CS}{CS}{CS}{CS}{CS}L")
    return seg("MRG",
        f"{old_pid}{CS}{CS}{CS}{e.name_kurz}{CS}MR{CS}{e.name_kurz}",  # MRG-1 Prior Patient ID List
        "",                                           # MRG-2 Prior Alternate PID (deprecated)
        f"{old_pid}{CS}{CS}{CS}{e.name_kurz}{CS}MR{CS}{e.name_kurz}",  # MRG-3 Prior Patient ID
        old_fall or "",                               # MRG-4 Prior Patient Account Number
        "",                                           # MRG-5 Prior Patient Visit Number (deprecated)
        "",                                           # MRG-6 Prior Patient Alternate Visit ID
        prior_name,                                   # MRG-7 Prior Patient Name
    )


# ────────────────────────────────────────────────────────────────────────────────
# Message-Builder pro Trigger-Event
# ────────────────────────────────────────────────────────────────────────────────
def _header(fall: Fall, trigger: str, struct: str, now: datetime,
            msg_seq: int) -> str:
    msg_id = f"ADT{ts(now,'S')}{msg_seq:04d}"
    return build_msh(trigger, struct, msg_id, now, fall.einrichtung)

def build_a01(fall: Fall, msg_seq: int) -> str:
    """A01 – Aufnahme stationär (Vollbild mit allen Aufnahmesegmenten)."""
    now = datetime.now()
    out = [_header(fall, "A01", "ADT_A01", now, msg_seq)]
    out.append(build_evn("A01", fall.aufnahme, now,
                          "ADM", "Stationäre Aufnahme",
                          fall.aufnehmender, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_nk1(1, fall.angehoeriger, fall.patient))
    out.append(build_pv1(fall, mode="admit"))
    out.append(build_pv2(fall, mode="admit"))
    out += build_obx_vitals(1, fall.koerpermass, fall.aufnahme, fall.einrichtung)
    for i, a in enumerate(fall.szenario.allergien, start=1):
        out.append(build_al1(i, a))
    for i, d in enumerate([fall.szenario.hauptdiagnose] + fall.szenario.nebendiagnosen,
                           start=1):
        out.append(build_dg1(i, d, fall.behandelnder, fall))
    out.append(build_gt1(fall.patient, fall))
    out.append(build_in1(fall.patient, fall))
    return SEG.join(out) + SEG

def build_a02(fall: Fall, msg_seq: int) -> str:
    """A02 – Verlegung (benötigt Prior Patient Location)."""
    now = datetime.now()
    out = [_header(fall, "A02", "ADT_A02", now, msg_seq)]
    verlegt = fall.aufnahme + timedelta(days=1, hours=4)
    out.append(build_evn("A02", verlegt, now, "TRX", "Interne Verlegung",
                          fall.behandelnder, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_pv1(fall, mode="transfer"))
    out.append(build_pv2(fall, mode="transfer"))
    return SEG.join(out) + SEG

def build_a03(fall: Fall, msg_seq: int) -> str:
    """A03 – Entlassung (Entlasszeit, Disposition, finale Diagnosen)."""
    now = datetime.now()
    out = [_header(fall, "A03", "ADT_A03", now, msg_seq)]
    out.append(build_evn("A03", fall.entlassung, now, "DSC",
                          "Reguläre Entlassung",
                          fall.entlassender, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_pv1(fall, mode="discharge"))
    out.append(build_pv2(fall, mode="discharge"))
    out += build_obx_vitals(1, fall.koerpermass, fall.entlassung, fall.einrichtung)
    for i, d in enumerate([fall.szenario.hauptdiagnose] + fall.szenario.nebendiagnosen,
                           start=1):
        out.append(build_dg1(i, d, fall.behandelnder, fall))
    out.append(build_gt1(fall.patient, fall))
    out.append(build_in1(fall.patient, fall))
    return SEG.join(out) + SEG

def build_a04(fall: Fall, msg_seq: int) -> str:
    """A04 – Ambulante Registrierung. Gleiche Struktur wie A01."""
    fall.szenario.patient_class = "O"  # Outpatient
    now = datetime.now()
    out = [_header(fall, "A04", "ADT_A01", now, msg_seq)]
    out.append(build_evn("A04", fall.aufnahme, now, "REG",
                          "Ambulante Registrierung",
                          fall.aufnehmender, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_pv1(fall, mode="outpatient"))
    out.append(build_pv2(fall, mode="outpatient"))
    for i, d in enumerate([fall.szenario.hauptdiagnose] + fall.szenario.nebendiagnosen,
                           start=1):
        out.append(build_dg1(i, d, fall.behandelnder, fall))
    out.append(build_in1(fall.patient, fall))
    return SEG.join(out) + SEG

def build_a05(fall: Fall, msg_seq: int) -> str:
    """A05 – Vor-Aufnahme (Pre-Admit)."""
    now = datetime.now()
    out = [_header(fall, "A05", "ADT_A05", now, msg_seq)]
    pre_dt = fall.aufnahme - timedelta(days=7)
    out.append(build_evn("A05", pre_dt, now, "PRE", "Vor-Aufnahme geplant",
                          fall.aufnehmender, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_nk1(1, fall.angehoeriger, fall.patient))
    out.append(build_pv1(fall, mode="preadmit"))
    out.append(build_pv2(fall, mode="preadmit"))
    for i, a in enumerate(fall.szenario.allergien, start=1):
        out.append(build_al1(i, a))
    for i, d in enumerate([fall.szenario.hauptdiagnose] + fall.szenario.nebendiagnosen,
                           start=1):
        out.append(build_dg1(i, d, fall.behandelnder, fall))
    out.append(build_in1(fall.patient, fall))
    return SEG.join(out) + SEG

def build_a08(fall: Fall, msg_seq: int) -> str:
    """A08 – Update Patient Information. Struktur wie A01, nur abgespeckt."""
    now = datetime.now()
    out = [_header(fall, "A08", "ADT_A01", now, msg_seq)]
    out.append(build_evn("A08", now, now, "UPD",
                          "Aktualisierung der Patientenstammdaten",
                          fall.behandelnder, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_nk1(1, fall.angehoeriger, fall.patient))
    out.append(build_pv1(fall, mode="current"))
    out.append(build_in1(fall.patient, fall))
    return SEG.join(out) + SEG

def build_a11(fall: Fall, msg_seq: int) -> str:
    """A11 – Aufnahme stornieren."""
    now = datetime.now()
    out = [_header(fall, "A11", "ADT_A09", now, msg_seq)]
    out.append(build_evn("A11", now, now, "CNC",
                          "Aufnahme storniert – Patient nicht erschienen",
                          fall.aufnehmender, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_pv1(fall, mode="cancel"))
    out.append(build_pv2(fall, mode="cancel"))
    return SEG.join(out) + SEG

def build_a13(fall: Fall, msg_seq: int) -> str:
    """A13 – Entlassung stornieren."""
    now = datetime.now()
    out = [_header(fall, "A13", "ADT_A01", now, msg_seq)]
    out.append(build_evn("A13", now, now, "CND",
                          "Entlassung storniert – Patient bleibt stationär",
                          fall.behandelnder, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_pd1(fall.patient, fall.hausarzt))
    out.append(build_pv1(fall, mode="current"))
    out.append(build_pv2(fall, mode="current"))
    out.append(build_in1(fall.patient, fall))
    return SEG.join(out) + SEG

def build_a40(fall: Fall, old_pid: str, old_patient: Patient,
              msg_seq: int) -> str:
    """A40 – Patienten-Merge. fall.patient ist der überlebende Datensatz."""
    now = datetime.now()
    out = [_header(fall, "A40", "ADT_A39", now, msg_seq)]
    out.append(build_evn("A40", now, now, "MRG",
                          f"Merge Dublette {old_pid} → {fall.patient.pid}",
                          fall.behandelnder, fall.einrichtung))
    out.append(build_pid(fall.patient, fall.einrichtung, fall))
    out.append(build_mrg(old_pid, old_patient, fall.einrichtung,
                          old_fall=f"OLD-{fall.fallnummer}"))
    out.append(build_pv1(fall, mode="current"))
    return SEG.join(out) + SEG


# ────────────────────────────────────────────────────────────────────────────────
# Patient/Fall Generierung
# ────────────────────────────────────────────────────────────────────────────────
def gen_patient(rnd: random.Random, idx: int) -> Patient:
    g = rnd.choice(["M", "F"])
    vn = rnd.choice(VORNAMEN_M if g == "M" else VORNAMEN_F)
    nn = rnd.choice(NACHNAMEN)
    gebn = rnd.choice(NACHNAMEN) if g == "F" and rnd.random() < 0.6 else ""
    strasse_basis, plz, ort = rnd.choice(STRASSEN)
    geb = datetime(rnd.randint(1938, 1990), rnd.randint(1, 12), rnd.randint(1, 28))
    kasse = rnd.choice(KASSEN)
    kvnr = f"{rnd.choice('ABCDEFGHJKLMNPRSTUWXYZ')}{rnd.randint(100000000, 999999999)}"
    return Patient(
        pid=f"P{100000 + idx:06d}",
        nachname=nn, vorname=vn,
        titel=rnd.choice(["", "", "", "Dr.", "Prof. Dr.", "Dipl.-Ing."]),
        geburtsname=gebn,
        geburtsdatum=geb.strftime("%Y%m%d"),
        geschlecht=g,
        strasse=f"{strasse_basis} {rnd.randint(1,199)}",
        plz=plz, ort=ort, land="DEU",
        geburtsort=rnd.choice(["München","Augsburg","Regensburg","Nürnberg","Ingolstadt","Rosenheim"]),
        tel_privat=f"+49-89-{rnd.randint(100,999)}{rnd.randint(1000,9999)}",
        tel_mobil=f"+49-1{rnd.choice([51,60,62,70,75,77])}-{rnd.randint(1000000,9999999)}",
        email=f"{vn.lower()}.{nn.lower()}@example.de".replace("ä","ae").replace("ö","oe").replace("ü","ue").replace("ß","ss"),
        staatsangehoerigkeit="DEU",
        familienstand=rnd.choice(["S","M","D","W"]),
        konfession=rnd.choice(["RKC","LUT","NONE","NONE"]),
        beruf=rnd.choice(BERUFE),
        arbeitgeber=rnd.choice(["Eigenständig","MVV GmbH","BMW AG","Siemens AG","Stadt München","—"]),
        versicherten_nr=kvnr,
        kasse=kasse,
    )

def gen_angehoeriger(rnd: random.Random, p: Patient) -> Angehoeriger:
    # Ehepartner 50%, Kind 30%, Geschwister 20%
    r = rnd.random()
    if r < 0.5 and p.familienstand == "M":
        bez = "SPO"; bez_text = "Ehepartner/in"
        other_g = "F" if p.geschlecht == "M" else "M"
    elif r < 0.8:
        bez = "CHD"; bez_text = "Kind"
        other_g = rnd.choice(["M","F"])
    else:
        bez = rnd.choice(["BRO","SIS"])
        bez_text = "Bruder" if bez == "BRO" else "Schwester"
        other_g = "M" if bez == "BRO" else "F"
    vn = rnd.choice(VORNAMEN_M if other_g == "M" else VORNAMEN_F)
    nn = p.nachname if bez in ("SPO","CHD") else rnd.choice(NACHNAMEN)
    return Angehoeriger(
        nachname=nn, vorname=vn,
        beziehung=bez, beziehung_text=bez_text,
        strasse=p.strasse, plz=p.plz, ort=p.ort,
        telefon=p.tel_privat,
        mobil=f"+49-1{rnd.choice([51,60,62,70,75,77])}-{rnd.randint(1000000,9999999)}",
    )

def gen_koerpermass(rnd: random.Random, p: Patient) -> Koerpermass:
    basis_gr = 175 if p.geschlecht == "M" else 165
    return Koerpermass(
        groesse_cm=round(rnd.gauss(basis_gr, 8), 0),
        gewicht_kg=round(rnd.gauss(78 if p.geschlecht == "M" else 68, 12), 1),
        rr_sys_mmhg=int(round(rnd.gauss(135, 15))),
        rr_dia_mmhg=int(round(rnd.gauss(82, 10))),
        puls_min=int(round(rnd.gauss(78, 12))),
        temperatur_c=round(rnd.gauss(37.0, 0.4), 1),
    )

def gen_fall(rnd: random.Random, idx: int,
             scenario_filter: Optional[str] = None) -> Fall:
    if scenario_filter:
        szens = [s for s in SZENARIEN if s.key == scenario_filter]
        if not szens:
            raise ValueError(f"Unbekanntes Szenario: {scenario_filter}. "
                             f"Verfügbar: {[s.key for s in SZENARIEN]}")
        sz = szens[0]
    else:
        sz = rnd.choice(SZENARIEN)

    # Szenario flach klonen damit Mutationen in build_a04 den Katalog nicht verändern
    sz = Szenario(**{f.name: getattr(sz, f.name) for f in sz.__dataclass_fields__.values()})

    pat = gen_patient(rnd, idx)
    aufnahme = datetime(2026, rnd.randint(1, 4), rnd.randint(1, 28),
                        rnd.randint(7, 20), rnd.choice([0, 15, 30, 45]))
    entlassung = aufnahme + timedelta(days=sz.durchschn_verweildauer_tage,
                                       hours=rnd.randint(0, 5))
    fallnr = f"VN{ts(aufnahme,'D')}-{idx:04d}"

    return Fall(
        fallnummer=fallnr,
        aufnahme=aufnahme, entlassung=entlassung,
        patient=pat, szenario=sz,
        aufnehmender=rnd.choice(AERZTE),
        behandelnder=rnd.choice(AERZTE),
        entlassender=rnd.choice(AERZTE),
        hausarzt=rnd.choice(HAUSAERZTE),
        angehoeriger=gen_angehoeriger(rnd, pat),
        einrichtung=EINRICHTUNG,
        koerpermass=gen_koerpermass(rnd, pat),
        aktuelle_location=(sz.aufnahme_station, sz.zimmer, sz.bett),
        vorherige_location=None,
    )


# ────────────────────────────────────────────────────────────────────────────────
# Chain-Modus – vollständiger Fallverlauf als korrelierte Nachrichtenkette
# ────────────────────────────────────────────────────────────────────────────────
def build_chain(rnd: random.Random, fall: Fall, start_seq: int) -> List[str]:
    msgs: List[str] = []
    seq = start_seq

    # Bei elektiven Fällen: A05 (Vor-Aufnahme) voranschicken
    if fall.szenario.aufnahmeanlass == "E" and rnd.random() < 0.6:
        msgs.append(build_a05(fall, seq)); seq += 1

    # A01 Aufnahme
    msgs.append(build_a01(fall, seq)); seq += 1

    # A02 Verlegungen laut Szenario (0-2 Stück, je 1/3 Wahrscheinlichkeit)
    for neue_loc in fall.szenario.verlegungen:
        if rnd.random() < 0.6:
            fall.vorherige_location = fall.aktuelle_location
            fall.aktuelle_location = neue_loc
            msgs.append(build_a02(fall, seq)); seq += 1

    # Gelegentlich A08 (Stammdaten-Update während des Falls)
    if rnd.random() < 0.25:
        msgs.append(build_a08(fall, seq)); seq += 1

    # A03 Entlassung
    msgs.append(build_a03(fall, seq)); seq += 1

    return msgs


# ────────────────────────────────────────────────────────────────────────────────
# Dispatcher
# ────────────────────────────────────────────────────────────────────────────────
EVENTS = ["A01", "A02", "A03", "A04", "A05", "A08", "A11", "A13", "A40"]

def build_by_event(event: str, fall: Fall, msg_seq: int,
                   rnd: random.Random) -> str:
    if event == "A01": return build_a01(fall, msg_seq)
    if event == "A02":
        if fall.szenario.verlegungen:
            fall.vorherige_location = fall.aktuelle_location
            fall.aktuelle_location  = fall.szenario.verlegungen[0]
        return build_a02(fall, msg_seq)
    if event == "A03": return build_a03(fall, msg_seq)
    if event == "A04": return build_a04(fall, msg_seq)
    if event == "A05": return build_a05(fall, msg_seq)
    if event == "A08": return build_a08(fall, msg_seq)
    if event == "A11": return build_a11(fall, msg_seq)
    if event == "A13": return build_a13(fall, msg_seq)
    if event == "A40":
        # Zweiten Patienten als "aufzugebenden" Datensatz erzeugen
        old_pid = f"P{rnd.randint(900000, 999999):06d}"
        old = gen_patient(rnd, rnd.randint(900000, 999999))
        old.pid = old_pid
        return build_a40(fall, old_pid, old, msg_seq)
    raise ValueError(f"Unbekanntes Event: {event}")


# ────────────────────────────────────────────────────────────────────────────────
# CLI
# ────────────────────────────────────────────────────────────────────────────────
def main() -> int:
    parser = argparse.ArgumentParser(
        description="HL7 ADT Nachrichten-Generator für Hackathons",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-n", "--count", type=int, default=5,
                        help="Anzahl Nachrichten (bei --chain: Anzahl Fälle)")
    parser.add_argument("-o", "--output", type=str, default=None)
    parser.add_argument("--event", choices=EVENTS, default="A01",
                        help="Trigger-Event (Default: A01)")
    parser.add_argument("--mix", action="store_true",
                        help="Zufälliger Mix aller Events (überschreibt --event)")
    parser.add_argument("--chain", action="store_true",
                        help="Vollständige Fallverläufe (A05→A01→A02×n→A03) je Fall")
    parser.add_argument("--scenario", choices=[s.key for s in SZENARIEN], default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--mllp", action="store_true")
    parser.add_argument("--pretty", action="store_true",
                        help="Segmente mit \\n statt \\r (nur zur Anzeige)")
    args = parser.parse_args()

    rnd = random.Random(args.seed)
    msgs: List[str] = []
    seq = 1

    for i in range(args.count):
        fall = gen_fall(rnd, i + 1, args.scenario)
        if args.chain:
            msgs.extend(build_chain(rnd, fall, seq))
            seq += 10
        else:
            event = rnd.choice(EVENTS) if args.mix else args.event
            msgs.append(build_by_event(event, fall, seq, rnd))
            seq += 1

    # Anzeige/Rahmen
    if args.pretty:
        msgs = [m.replace(SEG, "\n") for m in msgs]
    if args.mllp:
        msgs = [MLLP_START + m + MLLP_END for m in msgs]
    separator = "" if args.mllp else ("\n\n" if args.pretty else SEG)
    payload = separator.join(msgs)

    if args.output:
        if args.mllp:
            with open(args.output, "wb") as f:
                f.write(payload.encode("utf-8"))
        else:
            with open(args.output, "w", encoding="utf-8", newline="") as f:
                f.write(payload)
        print(f"{len(msgs)} ADT-Nachricht(en) geschrieben → {args.output}",
              file=sys.stderr)
    else:
        if not args.mllp and not args.pretty:
            payload = payload.replace(SEG, "\n")
        sys.stdout.write(payload)
        if not payload.endswith("\n"):
            sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
